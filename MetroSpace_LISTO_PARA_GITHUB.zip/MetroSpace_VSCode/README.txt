METROSPACE - PROYECTO PARA VISUAL STUDIO CODE

Abre esta carpeta en VS Code.
Archivos principales: index.html, style.css y script.js.
Conserva toda la carpeta assets.
Para visualizar: instala Live Server y abre index.html con Open with Live Server.

Se conservaron el HTML, CSS y JavaScript originales del proyecto, separando sus estilos y scripts. La tipografía embebida se externalizó y el logo se guardó en assets/images.
